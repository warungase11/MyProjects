<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Voting System</title>
<script src="jscript/validation.js" type="text/javascript"></script>
</head>
<body bgcolor="#EBE9E9"><!--
<marquee>****** Welcome To Online Voting System ******* </marquee>
<center><font size='8' >
<a href="index.php">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="register.php">Register</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="login.php">Login</a></font></center> 
<br>-->
<br><!--
<!DOCTYPE html>
<html lang="en" dir="Itr">
<head>
	<meta charset="utf-8">
	<title>slide menu bar css</title>
	<link rel="stylesheet" type="text/css" href="style.css">
   
<script src="https://kit.fontawesome.com/a076d05399.js"> </script>
</head>
<body>
	<input type="checkbox" id="check">
	<label for="check">
		<i class="fas fa-bars" id="btn"></i>
		<i class="fas fa-times" id="cancel"></i>
	</label>
	<div class="sidebar">
		<header>my app</header>
		<ul>
			<li><a href="index.php"><i class="fas fa-qrcode"></i>Home</a></li>
			<li><a href="register.php"><i class="fas fa-link"></i>Register</a></li>
			<li><a href="login.php"><i class="fas fa-stream"></i>login</a></li>

			<li><a href="voter.php"><i class="fas fa-calendar-week">Home</i></a></li>
			<li><a href="lan_view.php"><i class="far fa-question-circle"></i>Vote Results</a></li>
			<li><a href="profile.php"><i class="fas fa-sliders-h"></i>profile</a></li>
			<li><a href="logout.php"><i class="far fa-envelope"></i>Logout</a></li>
			<li><a href="change_pass.php"><i class="fas fa-sliders-h"></i>Change Password</a></li>
		</ul>
		
	</div>
	<section></section>

</body>
</html>-->