
<!DOCTYPE html>
<html lang="en" dir="Itr">
<head>
	<meta charset="utf-8">
	<title>slide menu bar css</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
   
<script src="https://kit.fontawesome.com/a076d05399.js"> </script>
</head>
<body>
	<input type="checkbox" id="check">
	<label for="check">
		<i class="fas fa-bars" id="btn"></i>
		<i class="fas fa-times" id="cancel"></i>
	</label>
	<div class="sidebar">
		<header>my app</header>
		<ul>
			<li><a href="index.php"><i class="fas fa-qrcode"></i>Home</a></li>
			<li><a href="register.php"><i class="fas fa-link"></i>Register</a></li>
			<li><a href="login.php"><i class="fas  fa-unlock"></i>login</a></li>

			<!--<li><a href="voter.php"><i class="fas fa-calendar-week">Home</i></a></li>-->
			<li><a href="lan_view.php"><i class="far fa-question-circle"></i>Vote Results</a></li>
			<li><a href="profile.php"><i class="fas fa-user"></i>profile</a></li>
			<li><a href="logout.php"><i class="far fa-unlock"></i>Logout</a></li>
			<li><a href="change_pass.php"><i class="fas fa-key"></i>Change Password</a></li>
		</ul>
		
	</div>
	<section></section>

</body>
</html>
