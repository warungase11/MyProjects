<?php
if(!isset($_SESSION)) { 
session_start();
}
include "auth.php";
include "header_voter.php";
?>
<br>
<br>

<h4 style="color:#e60808;"><?php global $nam; echo $nam;?> </h4> 
<?php global $error; echo $error;?>  <br><br>            

<center>
	<link rel="stylesheet" type="text/css" href="style1.css">
<form action="change_pass_action.php" method="post" id="myform">
		<div class="registration-form">
			<h2><font size="6">Change Password </font></h2><br><br>

Current Password :
<br>
<input type="password" name="cpassword" placeholder="">
<br><br><br>
New Password:
<br>
<input type="password" name="npassword" value="">
<br><br><br>
Confirm New Password:<br>
<input type="password" name="cnpassword" value="" >
<br><br><br>
<!--<input type="submit" name="cpass" value="UPDATE" >-->
<center><input type="submit" name="cpass" value="udate" style="height:30px; width:100px; margin: 20px 0; padding: 5px 10px; border-radius: 5px; color: red; cursor: pointer;" /></center>
</form></div></center>
<script type="text/javascript">
var frmvalidator = new Validator("myform"); 
frmvalidator.addValidation("cpassword","req","Please enter Current Password"); 
frmvalidator.addValidation("cpassword","maxlen=50");
frmvalidator.addValidation("npassword","req","Please enter New Password"); 
frmvalidator.addValidation("npassword","maxlen=50");
frmvalidator.addValidation("cnpassword","req","Please enter Confirm New Password"); 
frmvalidator.addValidation("cnpassword","maxlen=50");
</script>
<br>
<br>
