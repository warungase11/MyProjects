<?php
if(!isset($_SESSION)) {
session_start();
}

if (isset($_SESSION['SESS_NAME'])!="") {
	header("Location: voter.php");
}

?>

<?php include "code.php";?>
<?php include "header.php";?>


<center><font size="4" >
	<link rel="stylesheet" type="text/css" href="style1.css">	
<form action="login_action.php" method="post" id="myform" >
	<div class="registration-form">
		<h2> Login Form</h2><br><br>
Username : 
<input type="text" name="username"> 
<br>
<br>
Password : 
<input type="password" name="password">
<br>
<br>
<input type="submit" name="login" value="login" style=" height:30px; width:100px; margin: 20px 0; padding: 5px 10px; border-radius: 5px; color: red; cursor: pointer;"> 

<?php global $nam; echo $nam; ?>
<?php global $error; echo $error; ?>
<Br><br><br>
<rm>
</div>
</font>
</center>

<script type="text/javascript"> 
var frmvalidator = new Validator("myform");
frmvalidator.addValidation("username" , "req" , "Please Enter Username");
frmvalidator.addValidation("username", "maxlen=50");
frmvalidator.addValidation("password", "req" , "Please Enter Password");
</script>
