
<?php 
include "header_voter.php";
?>
<center>
<?php
if(!isset($_SESSION)) { 
session_start();
}
include "auth.php";

?><br><br><br><br><Br><Br><Br>
<h3><center><font color="white" size="5">Voting So Far </font> </center></h3><br><br><br>

<?php
include "connection.php";
?> 

<?php 
$member = mysqli_query($con, 'SELECT * FROM languages' );

if (mysqli_num_rows($member)== 0 ) {
	echo '<font color="red">No results found</font>';
}

else {
      
	echo '<center><table><tr height="50" bgcolor="red">
<td width="30px">ID</td>		
<td width="100px">Party Name</td>
<td width="150px">description</td>
<td width="30px">VOTE_count</td>
</tr>';

while($mb=mysqli_fetch_object($member))
		{	
			$id=$mb->lan_id;
			$name=$mb->fullname;
			$about=$mb->about;
			$vote=$mb->votecount;
			echo '<tr bgcolor="#BBBEFF">';
	echo '<td>'.$id.'</td>';		
	echo '<td>'.$name.'</td>';
	echo '<td>'.$about.'</td>';
	echo '<td>'.$vote.'</td>';
	echo "</tr>";
		}
		echo'</table height="50"></center>';
	}
?>
</center>