<?php 
if(!isset($_SESSION)) {
session_start();
}
if (isset($_SESSION['SESS_NAME'])!="") {
	header("Location: voter.php");
}
?>

<?php global $nam; echo $nam; ?> 
<?php global $error; echo $error; ?>
<?php global $msg; echo $msg;?>
<?php include "header.php";?>
<?php include "code.php";?>

  <center>
	<link rel="stylesheet" type="text/css" href="style1.css">
<form action= "reg_action.php" method= "post" id="myform" >
	<div class="registration-form">
		<h2> Registration Form</h2><br><br>
Firstname:
<input type="text" name="firstname" value="" />
<br>
<br>
Lastname: 
<input type="text" name="lastname" value="" />
<br>
<br>
Username: 
<input type="text" name="username" value="" />
<br>
<br>
Password: 
<input type="password" name="password" value="" />
<br>
<br>
<div class="g-recaptcha" data-sitekey="6LeD3hEUAAAAAKne6ua3iVmspK3AdilgB6dcjST0">
<br>
<br><!--
<input type="submit" name="submit" value="Next" />-->

<input type="submit" name="submit" value="register" style="height:30px; width:100px; margin: 20px 0; padding: 5px 10px; border-radius: 5px; color: red; cursor: pointer;"/>



</form>
</font>
</div>
</center>
<script type= "text/javascript" >
 var frmvalidator = new Validator("myform"); 
 frmvalidator.addValidation("firstname","req","Please enter student firstname"); 
 frmvalidator.addValidation("firstname","maxlen=50");
 frmvalidator.addValidation("lastname","req","Please enter student lastname"); 
 frmvalidator.addValidation("lastname","maxlen=50");
 frmvalidator.addValidation("username","req","Please enter student username"); 
 frmvalidator.addValidation("username","maxlen=50");
 frmvalidator.addValidation("password","req","Please enter student password"); 
 frmvalidator.addValidation("password","minlen=6","Password must not be less than 6 characters.");

</script>