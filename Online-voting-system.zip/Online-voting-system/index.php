<?php include "header.php";
session_start();
if (isset($_SESSION['SESS_NAME'])!="") {
	header("Location: voter.php");
}
?>
<?php global $msg; echo $msg;?>
<!--
<p><center><legend><font color='#008000' size='18'>This system allows all registered users to vote for their favorite POLITICAL PARTY.</p>
<p>In order to make a vote you have to register first and then login.</font></legend></center>
    <p>
    &nbsp;&nbsp;</p>-->

<!DOCTYPE html>
<html lang="en" dir="Itr">
<head>
	<meta charset="utf-8">
	<title>slide menu bar css</title>
	<link rel="stylesheet" type="text/css" href="style.css">
   
<script src="https://kit.fontawesome.com/a076d05399.js"> </script>
</head>
<body>
	<input type="checkbox" id="check">
	<label for="check">
		<i class="fas fa-bars" id="btn"></i>
		<i class="fas fa-times" id="cancel"></i>
	</label>
	<div class="sidebar">
		<header>my app</header>
		<ul>
			<li><a href="index.php"><i class="fas fa-qrcode"></i>Home</a></li>
			<li><a href="register.php"><i class="fas fa-link"></i>Register</a></li>
			<li><a href="login.php"><i class="fas fa-stream"></i>login</a></li>

			<!--<li><a href="voter.php"><i class="fas fa-calendar-week">Home</i></a></li>-->
			<li><a href="lan_view.php"><i class="far fa-question-circle"></i>Vote Results</a></li>
			<li><a href="profile.php"><i class="fas fa-sliders-h"></i>profile</a></li>
			<li><a href="contact US"><i class="far fa-envelope"></i>Logout</a></li>
			<li><a href="change_pass.php"><i class="fas fa-sliders-h"></i>Change Password</a></li>
		</ul>
		
	</div>
	<section></section>

</body>
</html>
