<?php
if(!isset($_SESSION)) { 
session_start();
}
include "auth.php";
include "header_voter.php"; 
?><br><br><br>
<h4><font color="white" size="5"><center> Welcome <?php echo $_SESSION['SESS_NAME']; ?> </h4></center>

<center><h3>please Vote </h3></font></center><br><br>

<form action="submit_vote.php" name="vote" method="post" id="myform" >
<center><font size='6'color="white"> What is your favorite political party? <BR>
<input type="radio" name="lan" value="BJP">  BJP<BR>
<input type="radio" name="lan" value="CONGRESS">CONGRESS<BR>
<input type="radio" name="lan" value="MNS">   MNS<BR>
<input type="radio" name="lan" value="NOTA">  Shiv Sena<BR>
<input type="radio" name="lan" value="NIRDLIY"> NCP<BR>
</font></center><br><center>
</center>

<center><input type="submit" value="Submit Vote" name="submit" style="height:30px; width:100px; margin: 20px 0; padding: 5px 10px; border-radius: 5px; color: red; cursor: pointer;" /></center>
<?php global $msg; echo $msg; ?>
<?php global $error; echo $error; ?>
</form>
